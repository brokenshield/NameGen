from distutils.core import setup

setup(
	name			= 'NameGen',
	version			= '1.0.0',
	py_modules		= ['NameGen'],
	author			= 'brokenshield',
	author_email	= 'brokenshield@gmail.com',
	url				= 'http://delta14.com',
	description		= 'A short module for generating random names',
	)
